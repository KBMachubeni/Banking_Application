﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEECT221
{
   abstract class Accounts
    {


      public double balance;
   
        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }


        private string accountNumber;

        public string AccountNumber
        {
            get { return accountNumber; }
            set { accountNumber = value; }
        }


        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        private string accountType;
       
        public string AccountType
        {
            get { return accountType; }
            set { accountType = value; }
        }
        


        public Accounts() { }

     
        
       public Accounts(string firstName,string lastName,string accountNumber,int age,double balance,string accountType)
        {

           this.firstName= firstName;
           this.lastName=lastName;
           this.accountNumber = accountNumber;
           this.age = age;
           this.balance = balance;
           this.accountType = accountType;
        }




       public abstract void Deposit(string accnumber, string password,double amountin);
        public abstract void Withdrawal(string accnumber, string password,double amountout);


       public override string ToString()
       {
           return string.Format(@"
First Name:         {0}
LastName:           {1}
Account Number:     {2}
Age:                {3}
Balance:            {4}
Account Type        {5}", firstName, lastName, accountNumber, age,balance,accountType);
       }

    }
}
