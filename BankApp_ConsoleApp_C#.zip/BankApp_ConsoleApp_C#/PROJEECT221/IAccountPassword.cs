﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEECT221
{
  public interface IAccountPassword
    {
      bool ValidatePassword(string accnumber,string password);

    }
}
