﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PROJEECT221
{
    class CurrentAccount:Accounts,IAccountPassword
    {


    private double charge;

        public double Charge
        {
             set { charge = 0.1; }
        }


        private string password;
        
        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public CurrentAccount()
        { }        
        public CurrentAccount(string firstName, string lastName, string accountNumber, int age, double balance,string accountType, double charge, string password)
            : base(firstName, lastName, accountNumber, age,balance,accountType)
        {
            this.charge = charge;
            this.password = password;
            
        }



        public bool ValidatePassword(string accnumber,string password)
        {
            string filename = "Clients.txt";
            bool condition = false;
            try
            {
                FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite);
                StreamReader read = new StreamReader(infile);

                string name = "", surname = "", type = "";
                int age = 0;
                double bal ;

                string lines = " ";

                //double balance = 0.00;
                while ((lines = read.ReadLine()) != null)
                {
                    string[] fields = lines.Split(',');

                    if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                    {
                        name = fields[0];
                        surname = fields[1];
                        type = fields[6];
                        age = Convert.ToInt32(fields[2]);
                        bal = Double.Parse(fields[5]);
                        condition = true;

                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine(@"Welcome : SAVINGS ACCOUNT
Name                     :{0}
Surname                  :{1}
Account Type             :{2}
Age                      :{3}
Balance                  :{4:C}", name, surname, type, age, bal);
                        break;
                    }
                    else
                    {
                        condition = false;
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        throw new CustomExceptionClient();

                    }
                }
            }
            catch (CustomExceptionClient v)
            {

                Console.WriteLine(v);
            }
            catch (FileNotFoundException error)
            {
                Console.WriteLine(error.Message);
            }
            catch (DirectoryNotFoundException direct)
            {
                Console.WriteLine(direct.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            return condition;
        }


        public override void Withdrawal(string accnumber, string password, double amountout)
        {
            string filename = "Clients.txt";
            bool condition = false;
            FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite);
            StreamReader read = new StreamReader(infile);
            StreamWriter write = new StreamWriter(infile);
            string lines = " ";


            while ((lines = read.ReadLine()) != null)
            {
                string[] fields = lines.Split(',');


                if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                {
                    Console.Clear();
                    Console.WriteLine("Hello, {0}. your balance is: {1}", fields[0] + " " + fields[1], fields[5]);
                    double balance = Convert.ToDouble(fields[5]);
                    Console.WriteLine();

                    balance -= amountout;
                    fields[6] = balance.ToString();
                    Console.WriteLine("you have deposited {0}, new balance is {1}", amountout, fields[5]);
                    write.WriteLine(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]);
                    Console.WriteLine();
                    condition = true;
                    break;
                }
                else
                {
                    condition = false;
                }
            }
            read.Close();
            if (condition == false)
            {
                Console.Clear();
                Console.WriteLine("Client Does Not Exists");
            }
        }


        public override void Deposit(string accnumber, string password, double amountin)
        {
            string filename = "Clients.txt";
            bool condition = false;
            FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite);
            StreamReader read = new StreamReader(infile);
            StreamWriter write = new StreamWriter(infile);
            string lines = " ";


            while ((lines = read.ReadLine()) != null)
            {
                string[] fields = lines.Split(',');


                if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                {
                    Console.Clear();
                    Console.WriteLine("Hello, {0}. your balance is: {1}", fields[0] + " " + fields[1], fields[5]);
                    double balance = Convert.ToDouble(fields[5]);
                    Console.WriteLine();

                    balance += amountin;
                    fields[5] = balance.ToString();
                    Console.WriteLine("you have deposited {0}, new balance is {1}", amountin, fields[5]);
                    write.WriteLine(fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]);
                    Console.WriteLine();
                    condition = true;
                    break;
                }
                else
                {
                    condition = false;
                }
            }
            read.Close();
            if (condition == false)
            {
                Console.Clear();
                Console.WriteLine("Client Does Not Exists");
            }
        }
    

   


        public override string ToString()
        {
            return base.ToString();

        }
        

    }
}
