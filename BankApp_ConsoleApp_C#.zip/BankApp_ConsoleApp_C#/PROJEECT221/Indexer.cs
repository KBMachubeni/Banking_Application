﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PROJEECT221
{
    class Indexer
    {

     public   List<Accounts> people = new List<Accounts>();
        public Indexer()
     {

        
     }

        public Accounts this[string index]
        {
            get
            {


                foreach (var item in people)
                {

                    if (item.AccountNumber== index )
                    {
                        return item;   
                    }
                    
                }
                return null;
            
            
            }   
        }



    }
}
