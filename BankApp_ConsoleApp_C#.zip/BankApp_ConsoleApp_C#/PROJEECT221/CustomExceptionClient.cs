﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEECT221
{
    class CustomExceptionClient:Exception
    {
        public CustomExceptionClient() :base("Client Does Not Exist")
        { }

        public CustomExceptionClient(string message) : base(message)
        { }

        public CustomExceptionClient(string message,Exception inner) :base(message,inner)
        { }
    }
}
