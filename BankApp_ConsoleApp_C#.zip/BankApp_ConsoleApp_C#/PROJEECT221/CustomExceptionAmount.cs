﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJEECT221
{
    class CustomExceptionAmount:Exception
    {
          public CustomExceptionAmount() :base("Insufficient Amount")
        { }

        public CustomExceptionAmount(string message) : base(message)
        { }

        public CustomExceptionAmount(string message,Exception inner) :base(message,inner)
        { }
    }
}
