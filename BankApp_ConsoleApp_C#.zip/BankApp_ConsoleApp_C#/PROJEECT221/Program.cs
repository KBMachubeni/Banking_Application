﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PROJEECT221
{
    enum Menu {Open=1, View,Deposit,Withdrawal,Exit}
    class Program
    {
        static void Main(string[] args)
        {
          

           SavingsAccount program = new SavingsAccount();
           CurrentAccount current = new CurrentAccount();
           string backToMain = "";
            do{
                Console.ForegroundColor = ConsoleColor.White;               
            Console.WriteLine("-------------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine(@"                k and z bank            ");
            Console.WriteLine();
            Console.WriteLine("--------------------------------------------------------------");

            Console.WriteLine(@"

                    1.Open Account
                    2.View Account
                    3.Deposit 
                    4.Withdrawal
                    5.Exit");

            int input = int.Parse(Console.ReadLine());

            Menu menu = new Menu();
            menu = (Menu)input;

            switch (menu)
            {
                case Menu.Open:
                    Console.Clear();
                    Console.WriteLine(@"++++++++++++++++++++++++++++++++++++++++++++++++++
OPEN ACCOUNT
+++++++++++++++++++++++++++++++++++++++++++++++++++");
                     Console.WriteLine(@"Type of Account?
Savings OR Current");
                    string opt=Console.ReadLine();

                    if (opt == "Savings" || opt == "Current" || opt == "savings" || opt == "surrent")
                    {


                        Console.WriteLine("Please enter name");
                        string name = Console.ReadLine();
                        Console.WriteLine("Please enter surname");
                        string sname = Console.ReadLine();
                        //Console.WriteLine("Enter Account Number");
                        //string accnum = Console.ReadLine();
                        Console.WriteLine("Enter Age");
                        int age = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter new balance");
                        double balance = double.Parse(Console.ReadLine());
                   
                  
                //    string password = "";

                   

                     Random r = new Random();
                    int pass = r.Next(1000, 1999);  

                     string firstletterName = name.Substring(0, 1).ToUpper();
                    string firstletterSurname = sname.Substring(0, 1).ToUpper();


                    string passw = firstletterName + firstletterSurname + pass;

                    Random accounta = new Random();
                    int accountNumber = 1000000 + accounta.Next(1000, 1999);

                    List<Accounts> acc= new List<Accounts>();

                    string filename = "Clients.txt";
                    FileStream file = new FileStream(filename, FileMode.Append, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(file);

                    using (sw)
                    {

                        sw.WriteLine(name + ',' + sname + ',' + age + ',' +passw+ ',' + accountNumber + ',' + balance+','+opt);

                    }
                    Console.WriteLine("************************************");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Employee Successfully Added");
                    }
                    else
                    {
                        Console.WriteLine("********************************");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid Input");
                    }

                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine("Would you like to go back to the main menu?");
                        backToMain = Console.ReadLine();
                    break;
                case Menu.View:
                    Console.WriteLine(@"++++++++++++++++++++++++++++++++++++++++++++++++++
SEARCH ACCOUNT
+++++++++++++++++++++++++++++++++++++++++++++++++++");

                    Indexer index = new Indexer();
                    List<Accounts> people = index.people;

                    Console.WriteLine(@"Type of account?
1.Savings
2.Current");
                    int insert = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter account number");
                    string accountnumber = Console.ReadLine();
                    Console.WriteLine("Enter Password");
                    string passn = Console.ReadLine();
                    
                    if (insert == 1)
                    {
                        program.ValidatePassword(accountnumber, passn);
                    }
                    if (insert == 2)
                    {
                        current.ValidatePassword(accountnumber, passn);
                        
                    }
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine("Would you like to go back to the main menu?");
                        backToMain = Console.ReadLine();

                         break;

                case Menu.Deposit:
                    Console.Clear();

                    Console.WriteLine(@"++++++++++++++++++++++++++++++++++++++++++++++++++
DEPOSIT INTO ACCOUNT
+++++++++++++++++++++++++++++++++++++++++++++++++++");
                        Console.WriteLine(@"what type of account would you like to deposit into?
 1.Current Account
 2.Savings Account

select an option");
                       int  choice = int.Parse(Console.ReadLine());
                        Console.Clear();
                        
                    Console.WriteLine("enter acc number:");
                       string  acNumber =Console.ReadLine();
                        Console.WriteLine("enter password");
                        string    accpassword = Console.ReadLine();
                        if (choice == 1)
                        {
                                                       
                            if (current.ValidatePassword(acNumber,accpassword)==true)
                            {
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("enter amount to deposit");
                                int deposit = int.Parse(Console.ReadLine());

                                current.Deposit( acNumber, accpassword,deposit);
                            }

                        }


                        if (choice == 2)
                        {
                             
                            if (program.ValidatePassword(acNumber,accpassword)== true)
                            {
                                Console.ForegroundColor = ConsoleColor.White;

                                Console.WriteLine("enter amount to deposit");
                                int deposit = int.Parse(Console.ReadLine());

                                program.Deposit(acNumber, accpassword, deposit);
                            }
                        }


                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine("Would you like to go back to the main menu?");
                        backToMain = Console.ReadLine();
                    break;
                case Menu.Withdrawal:
                    Console.WriteLine(@"++++++++++++++++++++++++++++++++++++++++++++++++++
                            WITHDRAW FORM ACCOUNT
+++++++++++++++++++++++++++++++++++++++++++++++++++");

                      Console.WriteLine(@"what type of account would you like to deposit into?
 1.Current Account
 2.Savings Account

select an option");
                       int  decision = int.Parse(Console.ReadLine());
                        Console.Clear();
                        string password = "*";
                    Console.WriteLine("enter acc number:");
                       string  Number =Console.ReadLine();
                            //string accNumber = Console.ReadLine();
                            Console.WriteLine("enter password");
                          password = Console.ReadLine();
                   
                        if (decision == 1)
                        {
                                                       
                            if (current.ValidatePassword(Number,password)==true)
                            {
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("enter amount to withdraw");
                                int deposit = int.Parse(Console.ReadLine());

                                current.Deposit( Number, password,deposit);
                            }

                        }


                        if (decision == 2)
                        {
                             
                            if (program.ValidatePassword(Number,password)== true)
                            {
                                Console.ForegroundColor = ConsoleColor.White;

                                Console.WriteLine("enter amount to deposit");
                                int deposit = int.Parse(Console.ReadLine());

                                program.Deposit(Number,password, deposit);
                            }
                        }
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine("Would you like to go back to the main menu?");
                        backToMain = Console.ReadLine();

                    break;
                case Menu.Exit:
                    Environment.Exit(0);
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalidd Selection");
                    break;
            }





            } while (backToMain.ToUpper() == "YES" || backToMain.ToLower() == "yes" || backToMain.ToUpper() == "Y" || backToMain.ToLower() == "y");


            Console.ReadKey();
        }
    }
}
