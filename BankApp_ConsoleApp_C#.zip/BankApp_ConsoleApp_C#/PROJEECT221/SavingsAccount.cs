﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PROJEECT221
{

    class SavingsAccount:Accounts,IAccountPassword
    {
        private double charge;

        public double Charge
        {
            set { charge = 0.15; }
        }


        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        
           
        public SavingsAccount()
        { }

        public SavingsAccount(string firstName,string lastName,string accountNumber,int age,double balance,string accountType,double charge,string password) :base(firstName,lastName,accountNumber,age,balance,accountType)
        {
            this.charge = charge;
            this.password = password;
           
        }

        public bool ValidatePassword(string accnumber, string password)
        {

            string filename = "Clients.txt";
            bool condition = false;
            try
            {
                FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite);
                StreamReader read = new StreamReader(infile);

                string name = "", surname = "", type = "";
                int age = 0;
                double bal ;

                string lines = " ";

                //double balance = 0.00;
                while ((lines = read.ReadLine()) != null)
                {
                    string[] fields = lines.Split(',');

                    if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                    {
                        name = fields[0];
                        surname = fields[1];
                        type = fields[6];
                        age = Convert.ToInt32(fields[2]);
                        bal = double.Parse(fields[5]);
                        condition = true;
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine(@"Welcome : SAVINGS ACCOUNT
Name                     :{0}
Surname                  :{1}
Account Type             :{2}
Age                      :{3}
Balance                  :{4:C}", name, surname, type, age, bal);
                        break;
                    }
                    else
                    {
                        condition = false;
                        Console.Clear();
                        throw new CustomExceptionClient();

                    }
                }
            }
            catch (CustomExceptionClient v)
            {

                Console.WriteLine(v);
            }
            catch (FileNotFoundException error)
            {
                Console.WriteLine(error.Message);
            }
            catch (DirectoryNotFoundException direct)
            {
                Console.WriteLine(direct.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            return condition;


        }



        public override void Withdrawal(string accnumber, string password, double amountout)
        {
            string filename = "Clients.txt";
            bool condition = false;
            try { 
            FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite);
            StreamReader read = new StreamReader(infile);
            StreamWriter write = new StreamWriter(infile);
            string lines = " ";


            while ((lines = read.ReadLine()) != null)
            {
                string[] fields = lines.Split(',');


                if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                {

                    double balance = Convert.ToDouble(fields[5]);
                    Console.WriteLine();
                    if (balance < amountout)
                    {
                        throw new CustomExceptionAmount();
                    }
                    else
                    {
                        condition = true;
                        balance -= amountout - (balance * charge);
                        fields[5] = balance.ToString();
                        Console.WriteLine("you have deposited {0}, new balance is {1}", amountout, fields[5]);
                        string name = fields[0], surname = fields[1], passord = fields[3], acc = fields[4], type = fields[6];
                        int age = int.Parse(fields[2]);
                        double bal = double.Parse(fields[5]);
                        write.WriteLine(name + ',' + surname + ',' + age + ',' + passord + ',' + acc + ',' + type);
                        Console.WriteLine();

                    }
                }

                }
            }
            catch (CustomExceptionAmount b)
            {
                Console.WriteLine(b);
            }
        }
        


        public override void Deposit(string accnumber, string password, double amountin)
        {
            string filename = "Clients.txt";
            bool condition = false;
            try
            {
                FileStream infile = new FileStream(filename, FileMode.Open, FileAccess.Read);
                StreamReader read = new StreamReader(infile);
         StreamWriter write = new StreamWriter(infile);
                string lines = " ";
              


                while ((lines = read.ReadLine()) != null)
                {
                    string[] fields = lines.Split(',');


                    if (fields[4] == Convert.ToString(accnumber) && fields[3] == password)
                    {
                     
               
                        double balance = Convert.ToDouble(fields[5]);
                        Console.WriteLine();

                        balance += amountin;
                        fields[5] = balance.ToString();
                        Console.WriteLine("you have deposited {0}, new balance is {1}", amountin, fields[5]);
                     string   name=fields[0],surname= fields[1],passord= fields[3],acc=fields[4],type=fields[6];
                        int age= int.Parse(fields[2]);
                         double bal= double.Parse(fields[5]);
                     write.WriteLine(name+','+surname+','+age+','+passord+','+acc+','+type);
                        Console.WriteLine();
                        condition = true;
                        break;
                    }
                    else
                    {
                        condition = false;
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Client Does Not Exists");
                    }
                }
                read.Close();
               
            }
            catch(Exception v)
            {
                Console.WriteLine( v);
            }
        }

    


        public override string ToString()
        {
            return base.ToString();

        }

    }
}
